﻿using ArcusConsol.Tools.UserRolesCreator.Model;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArcusConsol.Tools.UserRolesCreator
{
    public class DataAccess
    {
        private Uri endpoint = new Uri("https://localhost:8081");
        private readonly string key = "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==";
        private readonly string databaseId = "Arcus";
        private string CollectionId = "UserRoles";
        DocumentClient documentClient;

        public DataAccess()
        {
            documentClient = new DocumentClient(endpoint, key);
        }

        public async Task<Document> CreateItemAsync(ArcusUserRole item)
        {
            return await documentClient.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseId, CollectionId), item);
        }

    }
}
