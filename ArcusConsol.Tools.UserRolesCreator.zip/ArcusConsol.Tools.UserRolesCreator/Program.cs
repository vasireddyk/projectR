﻿using System;
using System.Collections.Generic;
using System.Linq;
using ArcusConsol.Tools.UserRolesCreator.Model;
using Newtonsoft.Json;

namespace ArcusConsol.Tools.UserRolesCreator
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteoutRolesAndActions();
            //WriteoutJson();

            //WriteToDatabaseAsync();
            Console.Read();
        }

        private static void WriteoutJson()
        {
            Console.WriteLine("--------------Getting Json-------------------------------------------------");
            List<ArcusUserRole> arcusRoles = CreateArcusRoles(GetData());
            Console.WriteLine(JsonConvert.SerializeObject(arcusRoles));
            Console.WriteLine("Completed getting Json");
        }


        private static async void WriteToDatabaseAsync()
        {
            Console.WriteLine("--------------Writing to database -------------------------------------------------");
            List<ArcusUserRole> arcusRoles = CreateArcusRoles(GetData());

            int totalCount = arcusRoles.Count;
            int counter = 0;
            var da = new DataAccess();
            foreach (var arcusRole in arcusRoles)
            {
                Console.WriteLine("Writing row {0} of {1}", counter + 1, totalCount);
                await da.CreateItemAsync(arcusRole);
                Console.WriteLine("written row {0} of {1}", counter + 1, totalCount);
                counter++;
            }
            Console.WriteLine("Completed writing to database");
        }

        private static void WriteoutRolesAndActions()
        {
            Console.WriteLine("printing Roles and Operations");
            Console.WriteLine("---------------------------------------------------------------");

            var roleResourceAction = GetData();
            foreach (var item in roleResourceAction)
            {

                Console.WriteLine("{0} can {1} {2}", item.Item1, item.Item3, item.Item2);
            }
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Completed printing Roles and Operations");
        }

        private static Tuple<string, string, string>[] GetData()
        {
            Tuple<string, string, string>[] roleResourceAction =
            {
                    //promoter details
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.BusinessDevelopmentExecutive.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerBusinessDevelopment.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadOfBusinessDevelopment.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.CRMExecutive.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.CRMManager.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.PromoterDetails.ToString(),ArcusResourceActions.Read.ToString()),

                    //Project details
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.BusinessDevelopmentExecutive.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerBusinessDevelopment.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadOfBusinessDevelopment.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.CRMExecutive.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.CRMManager.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectDetails.ToString(),ArcusResourceActions.Read.ToString()),

                    //Architecture diagrams
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Upload .ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ArchitecturalDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),

                    //Structural diagrams
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Upload .ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.StructuralDiagrams.ToString(),ArcusResourceActions.Upload.ToString()),
                    
                    //SiteSurveyReport
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Upload .ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.SiteSurveyReport.ToString(),ArcusResourceActions.Upload.ToString()),
 
                    //SoilTestingReport
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Upload .ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.SoilTestingReport.ToString(),ArcusResourceActions.Upload.ToString()),
            
                    //BuildingPermission
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Upload.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Download.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Upload .ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.BuildingPermission.ToString(),ArcusResourceActions.Upload.ToString()),

                    //ProjectBOQTemplate
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBOQTemplate.ToString(),ArcusResourceActions.Read.ToString()),

                    //ProjectBOMTemplate
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBOMTemplate.ToString(),ArcusResourceActions.Read.ToString()),


                      //ProjectBBSTemplate
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectBBSTemplate.ToString(),ArcusResourceActions.Read.ToString()),

                    //ProjectCostTemplate
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectCostTemplate.ToString(),ArcusResourceActions.Read.ToString()),
                    
                    //ProjectSchedule
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.HeadofEngineering.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.RegionalManagerEngineering.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.QuantitySurveyor.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.planningEngineer.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterEngineer.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterSupervisor.ToString(),ArcusResourceNames.ProjectSchedule.ToString(),ArcusResourceActions.Read.ToString()),
                
                    //WbsReferenceData
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.WbsReferenceData.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.WbsReferenceData.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.WbsReferenceData.ToString(),ArcusResourceActions.Delete.ToString()),
        
                    //UserAdmin
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.SuperAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Delete.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Edit.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Read.ToString()),
                    Tuple.Create( ArcusUserRoleNames.PromoterAdmin.ToString(),ArcusResourceNames.UserAdmin.ToString(),ArcusResourceActions.Delete.ToString()),

            };

            return roleResourceAction;
        }
        private static List<ArcusUserRole> CreateArcusRoles(Tuple<string, string, string>[] roleResourceAction)
        {
            List<ArcusUserRole> arcusRoles = new List<ArcusUserRole>();

            foreach (var item in roleResourceAction)
            {
                var arcusResourceAction = new ArcusResourceAction() { Name = item.Item3 };

                if (arcusRoles.FirstOrDefault(r => r.Name == item.Item1) != null)
                {
                    var arcusRole = arcusRoles.FirstOrDefault(r => r.Name == item.Item1);

                    if ((arcusRole.Resources.FirstOrDefault(r => r.Name == item.Item2) != null))
                    {
                        var arcusResource = arcusRole.Resources.FirstOrDefault(r => r.Name == item.Item2);
                        arcusResource.Actions.Add(arcusResourceAction);
                    }
                    else
                    {
                        var arcusResource = new ArcusResource() { Name = item.Item2 };
                        arcusResource.Actions.Add(arcusResourceAction);
                        arcusRole.Resources.Add(arcusResource);
                    }
                }
                else
                {
                    var arcusRole = new ArcusUserRole() { Name = item.Item1 };
                    if ((arcusRole.Resources.FirstOrDefault(r => r.Name == item.Item2) != null))
                    {
                        var arcusResource = arcusRole.Resources.FirstOrDefault(r => r.Name == item.Item2);
                        arcusResource.Actions.Add(arcusResourceAction);
                    }
                    else
                    {
                        var arcusResource = new ArcusResource() { Name = item.Item2 };
                        arcusResource.Actions.Add(arcusResourceAction);
                        arcusRole.Resources.Add(arcusResource);
                    }
                    arcusRoles.Add(arcusRole);
                }
            }

            return arcusRoles;
        }
    }
}

