﻿namespace ArcusConsol.Tools.UserRolesCreator.Model
{
    public enum ArcusUserRoleNames 
    {
        SuperAdmin,
        HeadofEngineering,
        RegionalManagerEngineering ,
        QuantitySurveyor,
        planningEngineer,
        BusinessDevelopmentExecutive,
        RegionalManagerBusinessDevelopment,
        HeadOfBusinessDevelopment,
        CRMManager,
        CRMExecutive,
        PromoterAdmin,
        PromoterEngineer,
        PromoterSupervisor
    }

    public enum ArcusResourceNames
    {
        PromoterDetails,
        ProjectDetails,
        ArchitecturalDiagrams,
        StructuralDiagrams,
        SiteSurveyReport,
        SoilTestingReport,
        BuildingPermission,
        ProjectCostTemplate,
        ProjectBOQTemplate,
        ProjectBOMTemplate,
        ProjectBBSTemplate,
        ProjectSchedule,
        WbsReferenceData,
        UserAdmin,
    }

    public enum ArcusResourceActions
    {
        Read,
        Edit,
        Delete,
        Download,
        Upload
    }


    //string[] roles =    {
    //                        "SuperAdmin",
    //                        "HeadofEngineering",
    //                        "RegionalManagerEngineering" ,
    //                        "QuantitySurveyor",
    //                        "planningEngineer",
    //                        "BusinessDevelopmentExecutive",
    //                        "RegionalManagerBusinessDevelopment",
    //                        "HeadOfBusinessDevelopment",
    //                        "CRMManager",
    //                        "CRMExecutive",
    //                        "PromoterAdmin",
    //                        "PromoterEngineer",
    //                        "PromoterSupervisor"
    //                   };


    //string[] resources = {
    //                            "PromoterDetails",
    //                            "ProjectDetails",
    //                            "ArchitecturalDiagrams",
    //                            "StructuralDiagrams",
    //                            "SiteSurveyReport",
    //                            "SoilTestingReport",
    //                            "BuildingPermission",
    //                            "ProjectCostTemplate",
    //                            "ProjectBOQTemplate",
    //                            "ProjectBOMTemplate",
    //                            "ProjectBBSTemplate",
    //                            "ProjectSchedule"
    //                    };
    //string[] operations =
    //                        {
    //                            "Edit",
    //                            "Read",
    //                            "Delete"
    //                        };
}
