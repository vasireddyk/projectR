﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace ArcusConsol.Tools.UserRolesCreator.Model
{
    public class ArcusUserRole
    {
        public ArcusUserRole()
        {
            Resources = new List<ArcusResource>();
        }
        [JsonProperty(PropertyName ="name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "resources")] 
        public List<ArcusResource> Resources {get;}

    }
}
