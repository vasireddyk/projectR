﻿using Newtonsoft.Json;

namespace ArcusConsol.Tools.UserRolesCreator.Model
{
    public class ArcusResourceAction
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
    }
}