﻿

using Newtonsoft.Json;
using System.Collections.Generic;

namespace ArcusConsol.Tools.UserRolesCreator.Model
{
    public class ArcusResource
    {
        public ArcusResource()
        {
            Actions = new List<ArcusResourceAction>();
        }
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "actions")]
        public List<ArcusResourceAction> Actions{get; set;}
    }
}